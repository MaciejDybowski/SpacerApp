import Spacer from './Spacer';

export default Spacer;