import React from 'react'
import './About.css';

function About() {
    return (
        <div className='about'>
            <p>about</p>
        </div>
    )
}

export default About
